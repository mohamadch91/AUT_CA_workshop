/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Az Memari/az5/arrayMult/arrayMult4bit.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );


static void work_a_3108128482_1516540902_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    char *t40;
    char *t41;
    int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    char *t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned char t54;
    char *t55;
    char *t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned char t61;
    unsigned char t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;

LAB0:    xsi_set_current_line(32, ng0);

LAB3:    t1 = xsi_get_transient_memory(4U);
    memset(t1, 0, 4U);
    t2 = t1;
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = (3 - 3);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t9 = *((unsigned char *)t3);
    t10 = (t0 + 1192U);
    t11 = *((char **)t10);
    t12 = (1 - 3);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t10 = (t11 + t15);
    t16 = *((unsigned char *)t10);
    t17 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t16);
    *((unsigned char *)t2) = t17;
    t2 = (t2 + 1U);
    t18 = (t0 + 1032U);
    t19 = *((char **)t18);
    t20 = (2 - 3);
    t21 = (t20 * -1);
    t22 = (1U * t21);
    t23 = (0 + t22);
    t18 = (t19 + t23);
    t24 = *((unsigned char *)t18);
    t25 = (t0 + 1192U);
    t26 = *((char **)t25);
    t27 = (1 - 3);
    t28 = (t27 * -1);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t25 = (t26 + t30);
    t31 = *((unsigned char *)t25);
    t32 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t24, t31);
    *((unsigned char *)t2) = t32;
    t2 = (t2 + 1U);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t35 = (1 - 3);
    t36 = (t35 * -1);
    t37 = (1U * t36);
    t38 = (0 + t37);
    t33 = (t34 + t38);
    t39 = *((unsigned char *)t33);
    t40 = (t0 + 1192U);
    t41 = *((char **)t40);
    t42 = (1 - 3);
    t43 = (t42 * -1);
    t44 = (1U * t43);
    t45 = (0 + t44);
    t40 = (t41 + t45);
    t46 = *((unsigned char *)t40);
    t47 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t39, t46);
    *((unsigned char *)t2) = t47;
    t2 = (t2 + 1U);
    t48 = (t0 + 1032U);
    t49 = *((char **)t48);
    t50 = (0 - 3);
    t51 = (t50 * -1);
    t52 = (1U * t51);
    t53 = (0 + t52);
    t48 = (t49 + t53);
    t54 = *((unsigned char *)t48);
    t55 = (t0 + 1192U);
    t56 = *((char **)t55);
    t57 = (1 - 3);
    t58 = (t57 * -1);
    t59 = (1U * t58);
    t60 = (0 + t59);
    t55 = (t56 + t60);
    t61 = *((unsigned char *)t55);
    t62 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t54, t61);
    *((unsigned char *)t2) = t62;
    t63 = (t0 + 5408);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    t66 = (t65 + 56U);
    t67 = *((char **)t66);
    memcpy(t67, t1, 4U);
    xsi_driver_first_trans_fast(t63);

LAB2:    t68 = (t0 + 5264);
    *((int *)t68) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3108128482_1516540902_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    char *t40;
    char *t41;
    int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    char *t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned char t54;
    char *t55;
    char *t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned char t61;
    unsigned char t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;

LAB0:    xsi_set_current_line(33, ng0);

LAB3:    t1 = xsi_get_transient_memory(4U);
    memset(t1, 0, 4U);
    t2 = t1;
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = (3 - 3);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t9 = *((unsigned char *)t3);
    t10 = (t0 + 1192U);
    t11 = *((char **)t10);
    t12 = (2 - 3);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t10 = (t11 + t15);
    t16 = *((unsigned char *)t10);
    t17 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t16);
    *((unsigned char *)t2) = t17;
    t2 = (t2 + 1U);
    t18 = (t0 + 1032U);
    t19 = *((char **)t18);
    t20 = (2 - 3);
    t21 = (t20 * -1);
    t22 = (1U * t21);
    t23 = (0 + t22);
    t18 = (t19 + t23);
    t24 = *((unsigned char *)t18);
    t25 = (t0 + 1192U);
    t26 = *((char **)t25);
    t27 = (2 - 3);
    t28 = (t27 * -1);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t25 = (t26 + t30);
    t31 = *((unsigned char *)t25);
    t32 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t24, t31);
    *((unsigned char *)t2) = t32;
    t2 = (t2 + 1U);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t35 = (1 - 3);
    t36 = (t35 * -1);
    t37 = (1U * t36);
    t38 = (0 + t37);
    t33 = (t34 + t38);
    t39 = *((unsigned char *)t33);
    t40 = (t0 + 1192U);
    t41 = *((char **)t40);
    t42 = (2 - 3);
    t43 = (t42 * -1);
    t44 = (1U * t43);
    t45 = (0 + t44);
    t40 = (t41 + t45);
    t46 = *((unsigned char *)t40);
    t47 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t39, t46);
    *((unsigned char *)t2) = t47;
    t2 = (t2 + 1U);
    t48 = (t0 + 1032U);
    t49 = *((char **)t48);
    t50 = (0 - 3);
    t51 = (t50 * -1);
    t52 = (1U * t51);
    t53 = (0 + t52);
    t48 = (t49 + t53);
    t54 = *((unsigned char *)t48);
    t55 = (t0 + 1192U);
    t56 = *((char **)t55);
    t57 = (2 - 3);
    t58 = (t57 * -1);
    t59 = (1U * t58);
    t60 = (0 + t59);
    t55 = (t56 + t60);
    t61 = *((unsigned char *)t55);
    t62 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t54, t61);
    *((unsigned char *)t2) = t62;
    t63 = (t0 + 5472);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    t66 = (t65 + 56U);
    t67 = *((char **)t66);
    memcpy(t67, t1, 4U);
    xsi_driver_first_trans_fast(t63);

LAB2:    t68 = (t0 + 5280);
    *((int *)t68) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3108128482_1516540902_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    char *t40;
    char *t41;
    int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    char *t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned char t54;
    char *t55;
    char *t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned char t61;
    unsigned char t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;

LAB0:    xsi_set_current_line(34, ng0);

LAB3:    t1 = xsi_get_transient_memory(4U);
    memset(t1, 0, 4U);
    t2 = t1;
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = (3 - 3);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t9 = *((unsigned char *)t3);
    t10 = (t0 + 1192U);
    t11 = *((char **)t10);
    t12 = (3 - 3);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t10 = (t11 + t15);
    t16 = *((unsigned char *)t10);
    t17 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t16);
    *((unsigned char *)t2) = t17;
    t2 = (t2 + 1U);
    t18 = (t0 + 1032U);
    t19 = *((char **)t18);
    t20 = (2 - 3);
    t21 = (t20 * -1);
    t22 = (1U * t21);
    t23 = (0 + t22);
    t18 = (t19 + t23);
    t24 = *((unsigned char *)t18);
    t25 = (t0 + 1192U);
    t26 = *((char **)t25);
    t27 = (3 - 3);
    t28 = (t27 * -1);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t25 = (t26 + t30);
    t31 = *((unsigned char *)t25);
    t32 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t24, t31);
    *((unsigned char *)t2) = t32;
    t2 = (t2 + 1U);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t35 = (1 - 3);
    t36 = (t35 * -1);
    t37 = (1U * t36);
    t38 = (0 + t37);
    t33 = (t34 + t38);
    t39 = *((unsigned char *)t33);
    t40 = (t0 + 1192U);
    t41 = *((char **)t40);
    t42 = (3 - 3);
    t43 = (t42 * -1);
    t44 = (1U * t43);
    t45 = (0 + t44);
    t40 = (t41 + t45);
    t46 = *((unsigned char *)t40);
    t47 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t39, t46);
    *((unsigned char *)t2) = t47;
    t2 = (t2 + 1U);
    t48 = (t0 + 1032U);
    t49 = *((char **)t48);
    t50 = (0 - 3);
    t51 = (t50 * -1);
    t52 = (1U * t51);
    t53 = (0 + t52);
    t48 = (t49 + t53);
    t54 = *((unsigned char *)t48);
    t55 = (t0 + 1192U);
    t56 = *((char **)t55);
    t57 = (3 - 3);
    t58 = (t57 * -1);
    t59 = (1U * t58);
    t60 = (0 + t59);
    t55 = (t56 + t60);
    t61 = *((unsigned char *)t55);
    t62 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t54, t61);
    *((unsigned char *)t2) = t62;
    t63 = (t0 + 5536);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    t66 = (t65 + 56U);
    t67 = *((char **)t66);
    memcpy(t67, t1, 4U);
    xsi_driver_first_trans_fast(t63);

LAB2:    t68 = (t0 + 5296);
    *((int *)t68) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3108128482_1516540902_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned char t24;
    char *t25;
    char *t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    char *t40;
    char *t41;
    int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;

LAB0:    xsi_set_current_line(36, ng0);

LAB3:    t1 = xsi_get_transient_memory(4U);
    memset(t1, 0, 4U);
    t2 = t1;
    *((unsigned char *)t2) = (unsigned char)2;
    t2 = (t2 + 1U);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = (3 - 3);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t9 = *((unsigned char *)t3);
    t10 = (t0 + 1192U);
    t11 = *((char **)t10);
    t12 = (0 - 3);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t10 = (t11 + t15);
    t16 = *((unsigned char *)t10);
    t17 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t16);
    *((unsigned char *)t2) = t17;
    t2 = (t2 + 1U);
    t18 = (t0 + 1032U);
    t19 = *((char **)t18);
    t20 = (2 - 3);
    t21 = (t20 * -1);
    t22 = (1U * t21);
    t23 = (0 + t22);
    t18 = (t19 + t23);
    t24 = *((unsigned char *)t18);
    t25 = (t0 + 1192U);
    t26 = *((char **)t25);
    t27 = (0 - 3);
    t28 = (t27 * -1);
    t29 = (1U * t28);
    t30 = (0 + t29);
    t25 = (t26 + t30);
    t31 = *((unsigned char *)t25);
    t32 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t24, t31);
    *((unsigned char *)t2) = t32;
    t2 = (t2 + 1U);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t35 = (1 - 3);
    t36 = (t35 * -1);
    t37 = (1U * t36);
    t38 = (0 + t37);
    t33 = (t34 + t38);
    t39 = *((unsigned char *)t33);
    t40 = (t0 + 1192U);
    t41 = *((char **)t40);
    t42 = (0 - 3);
    t43 = (t42 * -1);
    t44 = (1U * t43);
    t45 = (0 + t44);
    t40 = (t41 + t45);
    t46 = *((unsigned char *)t40);
    t47 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t39, t46);
    *((unsigned char *)t2) = t47;
    t48 = (t0 + 5600);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    memcpy(t52, t1, 4U);
    xsi_driver_first_trans_fast(t48);

LAB2:    t53 = (t0 + 5312);
    *((int *)t53) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3108128482_1516540902_p_4(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(72, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (0 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t10 = (0 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 5664);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t15;
    xsi_driver_first_trans_delta(t16, 7U, 1, 0LL);

LAB2:    t21 = (t0 + 5328);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_3108128482_1516540902_init()
{
	static char *pe[] = {(void *)work_a_3108128482_1516540902_p_0,(void *)work_a_3108128482_1516540902_p_1,(void *)work_a_3108128482_1516540902_p_2,(void *)work_a_3108128482_1516540902_p_3,(void *)work_a_3108128482_1516540902_p_4};
	xsi_register_didat("work_a_3108128482_1516540902", "isim/mult_tb_isim_beh.exe.sim/work/a_3108128482_1516540902.didat");
	xsi_register_executes(pe);
}
